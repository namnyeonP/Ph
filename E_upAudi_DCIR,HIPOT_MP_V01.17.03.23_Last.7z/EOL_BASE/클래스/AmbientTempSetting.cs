﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EOL_BASE.클래스
{
    public class AmbientTempSetting
    {
        public AmbientTempSetting()
        {
        }

        string testitem;
        string lowerTemp1, lowerTemp2, lowerTemp3, lowerTemp4, lowerTemp5;
        string higherTemp1, higherTemp2, higherTemp3, higherTemp4, higherTemp5;
        string resist1, resist2, resist3, resist4, resist5;
        string cell_resist1, cell_resist2, cell_resist3, cell_resist4, cell_resist5;

        public string TestItem
        {
            get { return testitem; }
            set { testitem = value; }
        }

        public string LowerTemp1
        {
            get { return lowerTemp1; }
            set { lowerTemp1 = value; }
        }

        public string LowerTemp2
        {
            get { return lowerTemp2; }
            set { lowerTemp2 = value; }
        }

        public string LowerTemp3
        {
            get { return lowerTemp3; }
            set { lowerTemp3 = value; }
        }

        public string LowerTemp4
        {
            get { return lowerTemp4; }
            set { lowerTemp4 = value; }
        }

        public string LowerTemp5
        {
            get { return lowerTemp5; }
            set { lowerTemp5 = value; }
        }

        public string HigherTemp1
        {
            get { return higherTemp1; }
            set { higherTemp1 = value; }
        }

        public string HigherTemp2
        {
            get { return higherTemp2; }
            set { higherTemp2 = value; }
        }

        public string HigherTemp3
        {
            get { return higherTemp3; }
            set { higherTemp3 = value; }
        }

        public string HigherTemp4
        {
            get { return higherTemp4; }
            set { higherTemp4 = value; }
        }

        public string HigherTemp5
        {
            get { return higherTemp5; }
            set { higherTemp5 = value; }
        }

        public string Resistance1
        {
            get { return resist1; }
            set { resist1 = value; }
        }

        public string Resistance2
        {
            get { return resist2; }
            set { resist2 = value; }
        }

        public string Resistance3
        {
            get { return resist3; }
            set { resist3 = value; }
        }

        public string Resistance4
        {
            get { return resist4; }
            set { resist4 = value; }
        }

        public string Resistance5
        {
            get { return resist5; }
            set { resist5 = value; }
        }

        public string CellResistance1
        {
            get { return cell_resist1; }
            set { cell_resist1 = value; }
        }

        public string CellResistance2
        {
            get { return cell_resist2; }
            set { cell_resist2 = value; }
        }

        public string CellResistance3
        {
            get { return cell_resist3; }
            set { cell_resist3 = value; }
        }

        public string CellResistance4
        {
            get { return cell_resist4; }
            set { cell_resist4 = value; }
        }

        public string CellResistance5
        {
            get { return cell_resist5; }
            set { cell_resist5 = value; }
        }
    }
}
